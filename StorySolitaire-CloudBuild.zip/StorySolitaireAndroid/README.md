# Story Solitaire Android test project

This is a native Android WebView wrapper around the playable Story Solitaire prototype. It runs locally and does not require an internet connection once installed.

## Build an APK in Android Studio
1. Install Android Studio on a Windows, macOS, or Linux computer.
2. Open this `StorySolitaireAndroid` folder as an existing project.
3. Allow Android Studio to install the Android SDK Platform 35 and the Android Gradle Plugin/Gradle dependencies when prompted.
4. Connect an Android tablet with USB debugging enabled, or select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy that APK to the tablet and install it. If prompted, allow installation from that file manager.

## Notes
- Package ID: `com.storysolitaire.game`
- Version: `0.1.0` (prototype)
- Minimum Android: Android 6.0 (API 23)
- Landscape orientation is enabled for tablet testing.
- The game assets and logic are stored in `app/src/main/assets/index.html`.
- This source project has not yet been compiled or tested on a physical tablet. This environment does not have the Android SDK or Gradle installed, so it cannot produce a verified APK here.

## Build in the cloud using GitHub Actions (no computer required after upload)
1. In a browser, sign in to GitHub and create a **private** repository named `story-solitaire`.
2. Upload the contents of this project folder to the repository (the files inside `StorySolitaireAndroid`, not the outer folder). Ensure the `.github/workflows/build-apk.yml` file is included.
3. Open the repository's **Actions** tab and select **Build Story Solitaire APK**.
4. Tap **Run workflow** and wait for the run to finish successfully.
5. Open the completed run and download the `story-solitaire-debug-apk` artifact. Extract the ZIP to get `app-debug.apk`.
6. Download `app-debug.apk` to your Samsung Tab and open it to install. Android may ask you to allow installation from your browser or file manager; only enable this for the app you intentionally downloaded.

The workflow builds a **debug/test APK**, not a Play Store release. A successful cloud build and actual installation/gameplay on the tablet still need to be confirmed.
